Hi Grader TA.

Everything should be self explanatory.  You do have to double click the mailboxes to get them to change.

I had a super busy week and JavaFX is all pretty new and different, so sorry about the quality of work! It is below my standards. :(

Anyways...

bye,

Zack